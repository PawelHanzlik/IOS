import UIKit

var string = "String"
var int = 2
var double = 0.4

let const_string:String = "const"
let const_int:Int = 5
let const_double:Double = 1.3

let const1 = string + " " + String(double)
let const2 = "\(string) \(double)"

var table = [1,2,3,4]
var dict = [1:"one",2:"two",3:"three"]
table.append(5)
dict[4] = "four"

var lotto = ["29-11-14":[1,2,3,4,5,6], "27-11-14":[10,11,12,13,14,15]]

var newDict = ["a":1,"b":2,"c":3]

let start = Int(("A" as UnicodeScalar).value)
var emptyDict:Dictionary = [Character: Int]()
for i in 0...9{
    var char = "A" as Character
    if let myScalar = UnicodeScalar(i+start){
        char = Character(myScalar)
    }
    emptyDict[char] = i
}
emptyDict
for (_,table) in lotto{
    for j in table{
        print(j)
    }
}

func NWD(num1 : Int, num2 : Int) -> Int{
    var n1 = num1
    var n2 = num2
    while(n1 != n2){
        if(n1 > n2){
            n1 = n1 - n2
        }
        else{
            n2 = n2 - n1
        }
    }
    return n1
}
NWD(num1 : 24, num2: 36)
